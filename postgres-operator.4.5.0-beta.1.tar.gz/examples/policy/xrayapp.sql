\c userdb;
create table xrayapp (id int, key varchar(40), value varchar(40));
create table a (id int);
create table xraycsvtable (name varchar(40), state varchar(40), zip varchar(40));

