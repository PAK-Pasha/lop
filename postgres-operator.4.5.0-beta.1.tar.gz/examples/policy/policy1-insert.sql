insert into policy1 (select now());
