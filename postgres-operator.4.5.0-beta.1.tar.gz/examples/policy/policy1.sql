\c userdb;
create table policy1 (id text);
grant all on policy1 to primaryuser;
