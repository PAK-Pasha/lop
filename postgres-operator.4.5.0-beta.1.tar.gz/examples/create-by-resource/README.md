# Example of Creating a Postgres Cluster With Resources

This has been moved to the documentation. Please see [Using Custom Resources](https://access.crunchydata.com/documentation/postgres-operator/latest/custom-resources/) in the [PostgreSQL Operator documentation](https://access.crunchydata.com/documentation/postgres-operator/).
